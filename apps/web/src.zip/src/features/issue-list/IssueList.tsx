// File: E:/civic-reporter/apps/web/src/features/issue-list/IssueList.tsx
import { useAppDispatch, useAppSelector } from "@/hooks/redux";
import { setSelectedIssue } from "@/store/slices/issuesSlice";

export function IssueList() {
  const dispatch = useAppDispatch();
  const { issues } = useAppSelector((state) => state.issues);

  return (
    <div className="bg-white p-4 rounded-lg shadow">
      <h2 className="font-bold mb-2">Issue List</h2>
      <ul>
        {issues.map(issue => (
          <li key={issue.id} onClick={() => dispatch(setSelectedIssue(issue.id))} className="cursor-pointer p-2 hover:bg-gray-100 rounded">
            {issue.description}
          </li>
        ))}
      </ul>
    </div>
  );
}