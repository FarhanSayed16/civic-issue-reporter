// File: E:/civic-reporter/apps/web/src/features/issue-list/IssueDetailsPanel.tsx
import { useAppSelector } from "@/hooks/redux";

export function IssueDetailsPanel() {
  const { issues, selectedIssueId } = useAppSelector((state) => state.issues);
  const selectedIssue = issues.find(issue => issue.id === selectedIssueId);

  if (!selectedIssue) {
    return <div className="bg-white p-4 rounded-lg shadow">Select an issue to see details.</div>;
  }

  return (
    <div className="bg-white p-4 rounded-lg shadow">
      <h2 className="font-bold mb-2">Details for Issue #{selectedIssue.id}</h2>
      <p><strong>Description:</strong> {selectedIssue.description}</p>
      <p><strong>Status:</strong> {selectedIssue.status}</p>
      <p><strong>Category:</strong> {selectedIssue.category}</p>
    </div>
  );
}