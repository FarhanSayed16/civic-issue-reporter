// File: E:/civic-reporter/apps/web/src/features/issue-map/MapView.tsx
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import { Issue } from '@/types';

interface MapViewProps {
  issues: Issue[];
}

export function MapView({ issues }: MapViewProps) {
  // Default location to Mumbai
  const position: [number, number] = [19.0760, 72.8777];

  return (
    <MapContainer center={position} zoom={12} style={{ height: '100%', width: '100%' }}>
      <TileLayer
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
      />
      {issues.map(issue => (
        <Marker key={issue.id} position={[issue.latitude, issue.longitude]}>
          <Popup>{issue.description}</Popup>
        </Marker>
      ))}
    </MapContainer>
  );
}