// src/features/api/user.api.js
import { apiSlice } from "./apiSlice";

export const userApi = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    registerUser: builder.mutation({
      query: (userData) => ({
        url: '/auth/register',
        method: 'POST',
        body: userData,
      }),
      // Typically you might not need cache invalidation here
    }),
    login: builder.mutation({
      query: (credentials) => ({
        url: '/auth/login',
        method: 'POST',
        body: credentials,
      }),
      invalidatesTags:['User']
    }),
    
    logout: builder.mutation({
      query: () => ({
        url: '/auth/logout',
        method: 'POST',
      }),
    }),

    refreshAccessToken: builder.mutation({
        query: () => ({
          url: '/auth/refresh-access-token',
          method: 'POST',
          credentials: 'include'
        }),
    }),

    changePassword: builder.mutation({
      query: (data) => ({
        url: '/auth/change-password',
        method: 'PATCH',
        body: data,
      }),
    }),

    updateAccountDetails: builder.mutation({
      query: (data) => ({
        url: '/auth/update-account-details',
        method: 'PATCH',
        body: data,
      }),
    }),

    getCurrentUser: builder.query({
        query: () => '/auth/me',
        providesTags: ['User','CurrentUser'],
        // Auto re-fetch when network reconnects
        onCacheEntryAdded: async (args, { updateCachedData, cacheEntryRemoved }) => {
          try {
            await cacheEntryRemoved;
            window.addEventListener('online', () => {
              updateCachedData((draft) => {
                draft.isAuthenticated = false;
              });
            });
          } catch {}
        }
      }),

    deleteUser: builder.mutation({
      query: (userId) => ({
        url: `/auth/delete-user/${userId}`,
        method: 'DELETE',
      }),
      invalidatesTags: ['User'],
    }),
    getAllUsers: builder.query({
      query: () => '/auth/get-all-users',
      providesTags: (result = [], error) => [
        { type: 'User', id: 'LIST' },
        ...result.data.map(u => ({ type: 'User', id: u._id })),
      ],
    }),
    updateUserRole: builder.mutation({
      query: ({ userId, role }) => ({
        url: `/auth/update-role/${userId}`,
        method: 'PATCH',
        body: { role },
      }),
      invalidatesTags: (result, error, { userId }) => [
        { type: 'User', id: 'LIST' },     // tells RTKQ to refetch the full list
        { type: 'User', id: userId },     // tells RTKQ to refetch this specific user
      ],
    }),
  }),
});

export const {
  useRegisterUserMutation,
  useLoginMutation,
  useLogoutMutation,
  useRefreshAccessTokenMutation,
  useChangePasswordMutation,
  useUpdateAccountDetailsMutation,
  useGetCurrentUserQuery,
  useDeleteUserMutation,
  useGetAllUsersQuery,
  useUpdateUserRoleMutation,
} = userApi;
