// File: E:/civic-reporter/apps/web/src/api/client.ts
import axios from 'axios';

const apiClient = axios.create({
  baseURL: 'http://localhost:8000', // Your local backend URL
});

export default apiClient;