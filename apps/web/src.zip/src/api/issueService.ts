// File: E:/civic-reporter/apps/web/src/api/issueService.ts
import { MOCK_ISSUES } from "@/_mock/issues";
import { Issue } from "@/types";

export const getAdminIssues = (): Promise<Issue[]> => {
  console.log("Fetching mock issues...");
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(MOCK_ISSUES);
    }, 500); // Simulate a 0.5 second network delay
  });
};