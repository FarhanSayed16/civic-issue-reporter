// File: E:/civic-reporter/apps/web/src/types/index.ts

export interface User {
  id: number;
  phone_number: string;
  full_name: string;
  role: 'citizen' | 'staff' | 'admin';
}

export interface Issue {
  id: number;
  description: string;
  status: 'new' | 'in_progress' | 'resolved' | 'rejected';
  category: string;
  latitude: number;
  longitude: number;
  upvote_count: number;
  image_url: string;
  reporter_id: number;
  created_at: string; // ISO date string
}

export interface Token {
  access_token: string;
  token_type: string;
}