// File: E:/civic-reporter/apps/web/src/pages/DashboardPage.tsx
import { useEffect } from 'react';
import { Header } from "@/components/Header";
import { Sidebar } from "@/features/issue-list/Sidebar"; // We will create this in the next step
import { MapView } from '@/features/issue-map/MapView';
import { IssueList } from '@/features/issue-list/IssueList';
import { IssueDetailsPanel } from '@/features/issue-list/IssueDetailsPanel';
import { useAppDispatch, useAppSelector } from '@/hooks/redux'; // We will create this hook
import { fetchIssues } from '@/store/slices/issuesSlice';

// It's good practice to create typed hooks
// Create a new file src/hooks/redux.ts and add the following:
/*
import { TypedUseSelectorHook, useDispatch, useSelector } from 'react-redux'
import type { RootState, AppDispatch } from '../store/store'
export const useAppDispatch: () => AppDispatch = useDispatch
export const useAppSelector: TypedUseSelectorHook<RootState> = useSelector
*/

export function DashboardPage() {
  const dispatch = useAppDispatch();
  const { issues, status } = useAppSelector((state) => state.issues);

  useEffect(() => {
    if (status === 'idle') {
      dispatch(fetchIssues());
    }
  }, [status, dispatch]);

  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar />
      <div className="flex-1 grid grid-cols-3 gap-4 p-4">
        <div className="col-span-2 flex flex-col gap-4">
          {/* Stats cards will go here */}
          <div className="flex-1 rounded-lg overflow-hidden">
            <MapView issues={issues} />
          </div>
        </div>
        <div className="col-span-1 flex flex-col gap-4">
          <IssueList />
          <IssueDetailsPanel />
        </div>
      </div>
    </div>
  );
}