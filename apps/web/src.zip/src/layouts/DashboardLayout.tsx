// File: E:/civic-reporter/apps/web/src/layouts/DashboardLayout.tsx
import React from 'react';

interface DashboardLayoutProps {
  children: React.ReactNode;
}

export function DashboardLayout({ children }: DashboardLayoutProps) {
  return (
    <div className="flex h-screen bg-gray-100">
      {/* We will add the Sidebar component here later */}
      <div className="flex-1 flex flex-col">
        {/* We will add the Header component here later */}
        <main className="flex-1 p-8">{children}</main>
      </div>
    </div>
  );
}