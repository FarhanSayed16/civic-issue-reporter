// File: E:/civic-reporter/apps/web/src/store/store.ts
import { configureStore } from '@reduxjs/toolkit';
import issuesReducer from './slices/issuesSlice'; // 👈 Import the reducer

export const store = configureStore({
  reducer: {
    issues: issuesReducer, // 👈 Add the reducer to the store
  },
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;