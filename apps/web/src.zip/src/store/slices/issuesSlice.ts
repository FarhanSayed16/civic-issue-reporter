// In src/store/slices/issuesSlice.ts

// Add selectedIssueId to the state interface
interface IssuesState {
  issues: Issue[];
  status: 'idle' | 'loading' | 'succeeded' | 'failed';
  selectedIssueId: number | null; // 👈 Add this
}

// Add it to the initial state
const initialState: IssuesState = {
  issues: [],
  status: 'idle',
  selectedIssueId: null, // 👈 Add this
};

const issuesSlice = createSlice({
  name: 'issues',
  initialState,
  reducers: { // 👈 Add this reducers section
    setSelectedIssue: (state, action) => {
      state.selectedIssueId = action.payload;
    },
  },
  extraReducers: (builder) => { /* ... (existing code) */ },
});

export const { setSelectedIssue } = issuesSlice.actions; // 👈 Export the new action
export default issuesSlice.reducer;