// File: E:/civic-reporter/apps/web/src/main.tsx
import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.tsx'
import './index.css'
import { Provider } from 'react-redux' // 👈 Import Provider
import { store } from './store/store.ts' // 👈 Import your store

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <Provider store={store}> {/* 👈 Wrap your App */}
      <App />
    </Provider>
  </React.StrictMode>,
)