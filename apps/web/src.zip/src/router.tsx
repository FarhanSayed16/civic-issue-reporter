// src/router.js
import React from 'react';
import { createBrowserRouter, createRoutesFromElements, Route } from 'react-router-dom';
import MainLayout from './layouts/DashboardLayout';
import AuthLayout from './layouts/AuthLayout';
import {
  HomePage,
  ProductDetailsPage,
  LoginPage,
  SignupPage,
  ProfilePage,

  CreateGigPage,
  GigsPage,
  GigDetailPage,
  ChatPage,
  FreelancerDashboard,
  ClientDashboard
} from './pages';
import { CancelPage, EarningsPage, MyGigsPage, MyOrdersPage, NotFound, SuccessPage } from './components';
import OrdersDashboard from './pages/OrdersDashboard';
// import AdminProductPage from './pages/AdminProductPage';
// import AdminUserRolePage from './pages/AdminUserRolePage';
// import AdminOrderManagementPage from './pages/AdminOrderManagementPage';

export default createBrowserRouter(
  createRoutesFromElements(
    <Route path="/" element={<MainLayout />}>
      {/* public */}
      <Route index element={<HomePage />} />
      <Route path="product/:id" element={<ProductDetailsPage />} />

      {/* login/signup (public but redirect away if already authed) */}
      <Route
        path="login"
        element={
          <AuthLayout authentication={false}>
            <LoginPage />
          </AuthLayout>
        }
      />
      <Route
        path="signup"
        element={
          <AuthLayout authentication={false}>
            <SignupPage />
          </AuthLayout>
        }
      />

      <Route
        path="gigs"
        element={
            <GigsPage />
        }
      />

      <Route
        path="gigs/:id"
        element={
            <GigDetailPage />
        }
      />

      <Route
        path="createGig"
        element={
          <AuthLayout authentication={true}>
            <CreateGigPage />
          </AuthLayout>
        }
      />

      <Route
        path="/success"
        element={
          <AuthLayout authentication={true}>
            <SuccessPage />
          </AuthLayout>
        }
      />
      <Route
        path="/cancel"
        element={
          <AuthLayout authentication={true}>
            <CancelPage />
          </AuthLayout>
        }
      />

      <Route
        path="/orders"
        element={
          <AuthLayout authentication={true}>
            <OrdersDashboard />
          </AuthLayout>
        }
      />

      <Route
        path="/chat"
        element={
          <AuthLayout authentication={true}>
            <ChatPage />
          </AuthLayout>
        }
      />

  
      <Route
        path="profile"
        element={
          <AuthLayout authentication={true}>
            <ProfilePage />
          </AuthLayout>
        }
      />

      <Route path="/dashboard/freelancer" element={<AuthLayout roles={'freelancer'}> <FreelancerDashboard /></AuthLayout>}>
        <Route index element={<MyGigsPage />} />
        <Route path="gigs"      element={<MyGigsPage />} />
        <Route path="orders"    element={<MyOrdersPage />} /> 
        <Route path="earnings"  element={<EarningsPage />} />
      </Route>

      <Route path="/dashboard/client" element={<AuthLayout roles={'client'}><ClientDashboard /></AuthLayout> }>
        <Route index element={<MyGigsPage />} />
        <Route path="gigs"      element={<MyGigsPage />} />
        <Route path="orders"    element={<MyOrdersPage />} />
        <Route path="earnings"  element={<EarningsPage />} />
      </Route>
      
{/* 
      <Route
        path="measurement/:id?view=true"
        element={
          <AuthLayout authentication={true}>
            <MeasurementPage />
          </AuthLayout>
        }
      />
      <Route
        path="measurement/new"
        element={
          <AuthLayout authentication={true}>
            <MeasurementPage />
          </AuthLayout>
        }
      />
      <Route
        path="measurement/:id"
        element={
          <AuthLayout authentication={true}>
            <MeasurementPage />
          </AuthLayout>
        }
      />

      <Route
        path="checkout"
        element={
          <AuthLayout authentication={true}>
            <CheckoutPage />
          </AuthLayout>
        }
      />

      <Route
        path="orders/track"
        element={
          <AuthLayout authentication={true}>
            <OrderTrackingPage />
          </AuthLayout>
        }
      />

      <Route
        path="order/:id"
        element={
          <AuthLayout authentication={true}>
            <ViewDetailsPage />
          </AuthLayout>
        }
      />

      <Route
        path="/AdminUserRolePage"
        element={
          <AuthLayout authentication={true} roles={"admin"}>
            <AdminUserRolePage />
          </AuthLayout>
        }
      />

      <Route
        path="/AdminProductPage"
        element={
          <AuthLayout authentication={true} roles={"admin"}>
            <AdminProductPage />
          </AuthLayout>
        }
      />

      <Route
        path="/AdminOrderManagement"
        element={
          <AuthLayout authentication={true} roles={"admin"}>
            <AdminOrderManagementPage />
          </AuthLayout>
        }
      /> */}

      <Route path="*" element={<NotFound />} />
    </Route>
  )
);
