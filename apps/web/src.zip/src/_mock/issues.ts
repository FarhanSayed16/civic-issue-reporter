// File: E:/civic-reporter/apps/web/src/_mock/issues.ts
import { Issue } from "@/types"; // We will use the Issue type we defined in Phase B

export const MOCK_ISSUES: Issue[] = [
  { id: 1, description: 'Large pothole near Marine Drive', status: 'new', category: 'Pothole', latitude: 18.9440, longitude: 72.8239, upvote_count: 12, image_url: 'https://images.unsplash.com/photo-1593963339286-0343a4e3b8a8', reporter_id: 101, created_at: '2025-09-14T10:00:00Z' },
  { id: 2, description: 'Streetlight out at Andheri Station West', status: 'in_progress', category: 'Streetlight', latitude: 19.1196, longitude: 72.8464, upvote_count: 5, image_url: 'https://images.unsplash.com/photo-1620527940291-0d5b20894275', reporter_id: 102, created_at: '2025-09-13T14:30:00Z' },
  { id: 3, description: 'Garbage overflow near Juhu Beach entrance', status: 'resolved', category: 'Garbage', latitude: 19.0987, longitude: 72.8256, upvote_count: 2, image_url: 'https://images.unsplash.com/photo-1574939223842-9721c0b784a3', reporter_id: 101, created_at: '2025-09-12T09:00:00Z' }
];