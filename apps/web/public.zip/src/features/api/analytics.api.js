// src/features/api/analytics.api.js
import { apiSlice } from "./apiSlice";

export const analyticsApi = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    getStats: builder.query({
      query: (params = {}) => {
        const searchParams = new URLSearchParams();
        if (params.start_date) searchParams.append('start_date', params.start_date);
        if (params.end_date) searchParams.append('end_date', params.end_date);
        
        const queryString = searchParams.toString();
        return `/analytics/stats${queryString ? `?${queryString}` : ''}`;
      },
      providesTags: ['Analytics'],
    }),

    getHeatmapData: builder.query({
      query: (params = {}) => {
        const searchParams = new URLSearchParams();
        if (params.status) searchParams.append('status', params.status);
        if (params.category) searchParams.append('category', params.category);
        
        const queryString = searchParams.toString();
        return `/analytics/heatmap${queryString ? `?${queryString}` : ''}`;
      },
      providesTags: ['Analytics'],
    }),
  }),
});

export const {
  useGetStatsQuery,
  useGetHeatmapDataQuery,
} = analyticsApi;
