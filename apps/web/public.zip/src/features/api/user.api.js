// src/features/api/user.api.js
import { apiSlice } from "./apiSlice";

export const userApi = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    getMe: builder.query({
      query: () => '/users/me',
      providesTags: ['User'],
    }),

    getMyIssues: builder.query({
      query: () => '/users/me/issues',
      providesTags: ['Issue'],
    }),
  }),
});

export const {
  useGetMeQuery,
  useGetMyIssuesQuery,
} = userApi;
