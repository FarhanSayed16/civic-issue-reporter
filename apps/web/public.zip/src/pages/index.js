import HomePage from "./HomePage";
import SignupPage from "./SignupPage";
import LoginPage from "./LoginPage";
import ProfilePage from "./ProfilePage";

export {SignupPage,LoginPage,ProfilePage,HomePage,};