// File: E:/civic-reporter/apps/web/src/pages/DashboardPage.jsx
import React, { useState, useMemo } from 'react';
import PropTypes from 'prop-types';
import { 
  LayoutDashboard, 
  Filter, 
  Calendar,
  ArrowUpDown,
  MapPin,
  AlertTriangle,
  CheckCircle,
  Clock,
  Users
} from 'lucide-react';

// Import the hooks from your API slice files
import { useGetIssuesQuery } from '@/features/api/issues.api';
import { useGetStatsQuery } from '@/features/api/analytics.api';

// Import the components
import { MapView } from '@/components/MapView';
import { IssueList } from '@/components';
import { IssueDetailsPanel } from '@/components/IssueDetailsPanel';
import { Loader } from '@/components';

// Enhanced StatCard component with better icons and styling
function StatCard({ title, value, icon, color, bgColor, trend }) {
  return (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow duration-200">
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          <div className={`p-3 rounded-lg mr-4 ${bgColor}`}>
            {icon}
          </div>
          <div>
            <div className={`text-2xl font-bold ${color}`}>{value}</div>
            <div className="text-sm text-gray-500">{title}</div>
          </div>
        </div>
        {trend && (
          <div className="text-xs text-gray-400">
            {trend}
          </div>
        )}
      </div>
    </div>
  );
}

StatCard.propTypes = {
  title: PropTypes.string.isRequired,
  value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
  icon: PropTypes.node.isRequired,
  color: PropTypes.string.isRequired,
  bgColor: PropTypes.string.isRequired,
  trend: PropTypes.string,
};

// Filter button component
function FilterButton({ active, onClick, children, count }) {
  return (
    <button
      onClick={onClick}
      className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 flex items-center gap-2 ${
        active
          ? 'bg-blue-600 text-white shadow-md'
          : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'
      }`}
    >
      {children}
      {count !== undefined && (
        <span className={`text-xs px-2 py-1 rounded-full ${
          active ? 'bg-blue-500' : 'bg-gray-100'
        }`}>
          {count}
        </span>
      )}
    </button>
  );
}

FilterButton.propTypes = {
  active: PropTypes.bool.isRequired,
  onClick: PropTypes.func.isRequired,
  children: PropTypes.node.isRequired,
  count: PropTypes.number,
};

export default function HomePage() {
  // State for filters
  const [filters, setFilters] = useState({
    status: 'All Status',
    ward: 'All Wards',
    category: 'All Categories',
    sortBy: 'date'
  });

  // Fetch data
  const { data: issues, isLoading: issuesLoading, isError: issuesError } = useGetIssuesQuery();
  const { data: stats, isLoading: statsLoading, isError: statsError } = useGetStatsQuery();
  console.log('Fetched issues:', issues);
  console.log('Fetched stats:', stats);
  // Filter options
  const statusOptions = ['All Status', 'New', 'In Progress', 'Resolved'];
  const wardOptions = ['All Wards', 'Andheri', 'Bandra', 'Dadar', 'Mumbai Central', 'Thane'];
  const categoryOptions = ['All Categories', 'Pothole', 'Streetlight', 'Garbage', 'Water Issue', 'Road Problem', 'Other'];
  const sortOptions = [
    { value: 'date', label: 'Sort by Date' },
    { value: 'priority', label: 'Sort by Priority' },
    { value: 'status', label: 'Sort by Status' }
  ];

  // Filtered and sorted issues
  const filteredIssues = useMemo(() => {
    if (!issues) return [];
    
    let filtered = [...issues];
    
    // Apply filters
    if (filters.status !== 'All Status') {
      filtered = filtered.filter(issue => issue.status === filters.status);
    }
    
    if (filters.ward !== 'All Wards') {
      filtered = filtered.filter(issue => issue.ward === filters.ward);
    }
    
    if (filters.category !== 'All Categories') {
      filtered = filtered.filter(issue => issue.category === filters.category);
    }
    
    // Apply sorting
    filtered.sort((a, b) => {
      switch (filters.sortBy) {
        case 'date':
          return new Date(b.created_at) - new Date(a.created_at);
        case 'priority':
          const priorityOrder = { 'High': 3, 'Medium': 2, 'Low': 1 };
          return (priorityOrder[b.priority] || 0) - (priorityOrder[a.priority] || 0);
        case 'status':
          const statusOrder = { 'New': 3, 'In Progress': 2, 'Resolved': 1 };
          return (statusOrder[b.status] || 0) - (statusOrder[a.status] || 0);
        default:
          return 0;
      }
    });
    
    return filtered;
  }, [issues, filters]);

  // Count issues for each filter
  const getStatusCount = (status) => {
    if (!issues) return 0;
    if (status === 'All Status') return issues.length;
    return issues.filter(issue => issue.status === status).length;
  };

  const getWardCount = (ward) => {
    if (!issues) return 0;
    if (ward === 'All Wards') return issues.length;
    return issues.filter(issue => issue.ward === ward).length;
  };

  const getCategoryCount = (category) => {
    if (!issues) return 0;
    if (category === 'All Categories') return issues.length;
    return issues.filter(issue => issue.category === category).length;
  };

  // Loading state
  if (issuesLoading || statsLoading) {
    return (
      <div className="flex h-screen items-center justify-center bg-gray-50">
        <Loader />
      </div>
    );
  }

  // Error state
  // if (issuesError || statsError) {
  //   return (
  //     <div className="flex h-screen items-center justify-center text-red-500 bg-gray-50">
  //       <div className="text-center">
  //         <AlertTriangle className="mx-auto mb-4" size={48} />
  //         <p className="text-lg font-medium">Error fetching dashboard data</p>
  //         <p className="text-sm text-gray-500 mt-2">Please try refreshing the page</p>
  //       </div>
  //     </div>
  //   );
  // }

  return (
    <div className="flex h-[calc(100vh-theme(spacing.16))] bg-gray-50 z-0"> 
      
      {/* ===== LEFT FIXED COLUMN (MAP) ===== */}
      <div className="w-2/5 h-full">
        <div className="pt-28 h-[90%] bg-white rounded-r-xl border border-gray-200 shadow-sm overflow-hidden">
          <MapView issues={filteredIssues} />
        </div>
      </div>

      {/* ===== RIGHT SCROLLABLE COLUMN (CONTENT) ===== */}
      <div className="w-3/5 h-full overflow-y-auto bg-gray-50 pl-4">
        
        {/* Header Section */}
        <div className="sticky top-0 bg-white border-b border-gray-200 p-6 z-10">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 bg-blue-600 rounded-lg">
              <LayoutDashboard className="text-white" size={24} />
            </div>
            <h1 className="text-3xl font-bold text-gray-800">Admin Dashboard</h1>
          </div>

          {/* Enhanced Stats Cards */}
          <div className="grid grid-cols-2 gap-4 mb-6">
            <StatCard 
              title="New Issues" 
              value={stats?.new_issues || 0} 
              icon={<AlertTriangle size={20} className="text-white" />} 
              color="text-blue-600" 
              bgColor="bg-blue-500" 
              trend="+12% today"
            />
            <StatCard 
              title="In Progress" 
              value={stats?.in_progress || 0} 
              icon={<Clock size={20} className="text-white" />} 
              color="text-yellow-600" 
              bgColor="bg-yellow-500"
              trend="24 active"
            />
            <StatCard 
              title="Resolved Today" 
              value={stats?.resolved_today || 0} 
              icon={<CheckCircle size={20} className="text-white" />} 
              color="text-green-600" 
              bgColor="bg-green-500"
              trend="+8 from yesterday"
            />
            <StatCard 
              title="Total Pending" 
              value={stats?.total_pending || 0} 
              icon={<Users size={20} className="text-white" />} 
              color="text-red-600" 
              bgColor="bg-red-500"
              trend="Across all wards"
            />
          </div>
        </div>

        {/* Filters Section */}
        <div className="p-6 bg-white border-b border-gray-100">
          <div className="flex items-center gap-2 mb-4">
            <Filter size={16} className="text-gray-500" />
            <span className="text-sm font-medium text-gray-700">Filters</span>
          </div>
          
          {/* Status Filter */}
          <div className="mb-4">
            <div className="flex flex-wrap gap-2">
              {statusOptions.map((status) => (
                <FilterButton
                  key={status}
                  active={filters.status === status}
                  onClick={() => setFilters({ ...filters, status })}
                  count={getStatusCount(status)}
                >
                  {status}
                </FilterButton>
              ))}
            </div>
          </div>

          {/* Ward Filter */}
          <div className="mb-4">
            <div className="flex items-center gap-2 mb-2">
              <MapPin size={14} className="text-gray-400" />
              <span className="text-xs text-gray-500 uppercase tracking-wide">Wards</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {wardOptions.map((ward) => (
                <FilterButton
                  key={ward}
                  active={filters.ward === ward}
                  onClick={() => setFilters({ ...filters, ward })}
                  count={getWardCount(ward)}
                >
                  {ward}
                </FilterButton>
              ))}
            </div>
          </div>

          {/* Category Filter */}
          <div className="mb-4">
            <div className="flex flex-wrap gap-2">
              {categoryOptions.map((category) => (
                <FilterButton
                  key={category}
                  active={filters.category === category}
                  onClick={() => setFilters({ ...filters, category })}
                  count={getCategoryCount(category)}
                >
                  {category}
                </FilterButton>
              ))}
            </div>
          </div>

          {/* Sort Options */}
          <div className="flex items-center gap-2">
            <ArrowUpDown size={14} className="text-gray-400" />
            <select
              value={filters.sortBy}
              onChange={(e) => setFilters({ ...filters, sortBy: e.target.value })}
              className="text-sm border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              {sortOptions.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Content Section */}
        <div className="p-6">
          {/* Results Summary */}
          <div className="mb-4 p-4 bg-blue-50 rounded-lg border border-blue-100">
            <div className="flex items-center gap-2">
              <Calendar size={16} className="text-blue-600" />
              <span className="text-sm text-blue-800">
                Showing {filteredIssues.length} of {issues?.length || 0} issues
              </span>
            </div>
          </div>

          {/* Issue List Section */}
          <div className="mb-6">
            <IssueList issues={filteredIssues} />
          </div>
        </div>
      </div>
    </div>
  );
}