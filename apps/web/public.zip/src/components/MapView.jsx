// File: E:/civic-reporter/apps/web/src/features/issue-map/MapView.jsx
import React from 'react';
import PropTypes from 'prop-types';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';

export function MapView({ issues }) {
  // We'll center the map on Mumbai by default
  const position = [19.0760, 72.8777];

  return (
    <MapContainer center={position} zoom={12} style={{ height: '100%', width: '100%' }}>
      <TileLayer
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
      />
      {issues.map(issue => (
        <Marker key={issue.id} position={[issue.lat, issue.lng]}>
          <Popup>
            <b>Issue #{issue.id}</b><br />
            {issue.description}
          </Popup>
        </Marker>
      ))}
    </MapContainer>
  );
}

MapView.propTypes = {
  issues: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.number.isRequired,
      latitude: PropTypes.number.isRequired,
      longitude: PropTypes.number.isRequired,
      description: PropTypes.string.isRequired,
    })
  ).isRequired,
};